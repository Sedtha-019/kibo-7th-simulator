string data
